"use strict";
var Grocery = (function () {
    function Grocery() {
    }
    return Grocery;
}());
exports.Grocery = Grocery;
