import {Component,Input,Output,EventEmitter} from '@angular/core';
import {Grocery} from './app.grocery';
import {GroceryService} from './app.service';


@Component({
    selector:'<update-form></update-form>',
    templateUrl:'./app.searchupdate.html',
    providers:[GroceryService]
})

export class UpdateForm{
    
    @Input()
    updId:number;
    
    @Output()
    notify: EventEmitter<Grocery> = new EventEmitter<Grocery>();

    update:boolean=false;

    constructor(private groService: GroceryService) {}

    model:Grocery={
            id:null,
            name:null,
            type:null,
            price:null,
            mdate:null
    };

    
    groList:Grocery[];
    
    updateGrocery(id:number):void{
        this.model.id = id;
        this.notify.emit( this.model );
    }
    
    
}