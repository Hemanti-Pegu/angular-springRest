import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { HttpModule } from '@angular/http';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { ShowGrocery } from './app.showgrocery';
import { SearchPipe } from './filter';
import { SortingCompaniesPipe } from './app.sortingpipe';
import { UpdateForm } from './app.searchupdate';
import { AddGrocery } from './app.addgrocery';

const appRoutes: Routes = [
                           { path: 'addgrocery', component: AddGrocery },
                           { path: 'showgrocery', component: ShowGrocery }
                       ];

@NgModule( {
    imports: [BrowserModule, FormsModule, HttpModule, RouterModule.forRoot( appRoutes )],
    declarations: [AppComponent, ShowGrocery, SearchPipe, SortingCompaniesPipe, UpdateForm, AddGrocery],
    bootstrap: [AppComponent]
} )

export class AppModule { }
