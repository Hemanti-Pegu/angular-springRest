import { Component, OnInit } from '@angular/core';
import { Grocery } from './app.grocery';
import { GroceryService } from './app.service';
import { UpdateForm } from './app.searchupdate';
@Component( {
    
    templateUrl: './app.showgrocery.html',
    providers: [GroceryService]
} )

export class ShowGrocery implements OnInit {
 
    constructor( private groService: GroceryService ) { };

    ngOnInit(): void {
        this.groService.getAllGrocery().subscribe(( groData ) => this.groceries = groData );
    }
    
    search: string = '';
    column: string = '';
    statusmessage: string;
    
    del( id: number ): void {
        this.groService.deleteGrocery( id ).subscribe(( data ) => this.groceries = data,
            ( error ) => {
                this.statusmessage = "Problem with service check server"
                // console.error(error);
            } );
    }
    
    groceries: Grocery[];
    path: string[] = ['grocery'];
    order: number = 1; // 1 asc, -1 desc;
    
    sortTable(prop: string) {
      this.path = prop.split('.')
      this.order = this.order * (-1); // change order
      return false; // do not reload
    }
    
    update:boolean=false;
    updateId:number;
    updateGro(id:number):void{
        this.update = true;
        this.updateId = id;
    }
    
    onNotifyclick(gro:Grocery ): void {
        alert(gro.id + " " + gro.name + " " + gro.type + " " + gro.price);
        this.groService.updateGrocery(gro).subscribe((data) => {this.groceries = data},
        ( error ) => {
            this.statusmessage = "Problem with service check server"
            // console.error(error);
        } );
    }
    
    
    onNotify(msg:string): void {
        this.groService.getAllGrocery().subscribe(( groData ) => this.groceries = groData );
    }
    
}

