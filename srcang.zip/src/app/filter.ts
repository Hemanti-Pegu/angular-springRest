import { Pipe, PipeTransform } from '@angular/core';

@Pipe( {
    name: 'searchPipe'

} )
export class SearchPipe implements PipeTransform {
    transform( grocery: any, search: any,column:any ): any {
        if ( search == undefined || search=='') return grocery;
        if(column=='name'){
            return grocery.filter( function( item: any ) {
                console.log( item );
                return item.name.toLowerCase().includes( search.toLowerCase() );
            } )
        }
        if(column=='id'){
            return grocery.filter( function( item: any ) {
                console.log( item );
                return item.id.toString().includes( search );
            } )
        }
        if(column=='type'){
            return grocery.filter( function( item: any ) {
                console.log( item );
                return item.type.toLowerCase().includes( search.toLowerCase() );
            } )
        }
        if(column=='price'){
            return grocery.filter( function( item: any ) {
                console.log( item );
                return item.price.toString().includes( search );
            } )
        }
        if(column=='mdate'){
            return grocery.filter( function( item: any ) {
                console.log( item );
                return item.mdate.toString().includes( search );
            } )
        }
        return grocery.filter( function( item: any ) {
            console.log( item );
            return item.empName.toLowerCase().includes( search.toLowerCase() );
        } )
    }

}
