import {Component,Output,EventEmitter} from '@angular/core';
import {Grocery} from './app.grocery';
import {GroceryService} from './app.service';
import { NgForm } from "@angular/Forms/forms";


@Component({
   
    templateUrl:'./app.addgrocery.html',
    providers:[GroceryService]
})
export class AddGrocery{
  
    @Output()
    notify: EventEmitter<string> = new EventEmitter<string>();
    
    constructor(private groService:GroceryService) {}
    
    gro:Grocery={
            id:null,
            name:null,
            type:null,
            price:null
    };
    
    groList:Grocery[];
    
    checkMsg(msg:string){
        if(msg=='success'){
            //window.location.href = 'http://localhost:3000/showgrocery';
            return true;
        }
        
    }
    
    msg:string='';
    submitForm(ngform: NgForm){
        console.log(this.gro);
        this.groService.addGrocery(this.gro).subscribe((data) => {
            this.notify.emit(data);
            this.msg=data;
            
        });
        
    }
    
}