package com.cg.groceryapp.staticdb;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import com.cg.groceryapp.bean.Grocery;

public class GroceryDB {
	
	static List<Grocery> groceryList = new ArrayList<Grocery>();
	
	static{
		
		groceryList.add(new Grocery(1,"Tomato",30,"Vegie",Date.valueOf("2009-12-31")));
		groceryList.add(new Grocery(2,"Kaddu",20,"Vegie",Date.valueOf("2009-12-31")));
		groceryList.add(new Grocery(3,"Apple",130,"Fruit",Date.valueOf("2009-12-31")));
		groceryList.add(new Grocery(4,"Orange",40,"Fruit",Date.valueOf("2009-12-31")));
		groceryList.add(new Grocery(5,"Fenugreek",30,"Vegie",Date.valueOf("2009-12-31")));
		groceryList.add(new Grocery(6,"Kiwi",140,"Fruit",Date.valueOf("2009-12-31")));
		groceryList.add(new Grocery(7,"Brinjal",55,"Vegie",Date.valueOf("2009-12-31")));
		groceryList.add(new Grocery(8,"Toor",60,"Cereal",Date.valueOf("2009-12-31")));
	}
	
	public static List<Grocery> getGroList(){
		return groceryList;
	}
	
	public static void del(int id){
		groceryList.removeIf((a) -> {
			
			if(a.getId()==id){
				return true;
			}
			return false;
			
		});
	}

	public static void update(Grocery gro) {
		groceryList.removeIf((a) -> {
			if(a.getId()==gro.getId()){
				return true;
			}
			return false;
		});
		groceryList.add(gro);
		
	}

	public static void addGrocery(Grocery gro) {
		int index = groceryList.size();
		gro.setId(index+1);
		groceryList.add(gro);
	}
}
