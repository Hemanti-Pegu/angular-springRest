package com.cg.groceryapp.bean;

import java.sql.Date;

public class Grocery {
	private int id;
	public Grocery(int id, String name, int price, String type, Date valueOf) {
		super();
		this.id = id;
		this.mdate = valueOf;
		this.name = name;
		this.price = price;
		this.type = type;
	}
	private Date mdate;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	private String name;
	private int price;
	private String type;
	public Grocery() {
		super();
		// TODO 
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	@Override
	public String toString() {
		return "Grocery [id=" + id + ", mdate=" + mdate + ", name=" + name
				+ ", price=" + price + ", type=" + type + "]";
	}
	public Date getMdate() {
		return mdate;
	}
	public void setMdate(Date mdate) {
		this.mdate = mdate;
	}
	
	
}
