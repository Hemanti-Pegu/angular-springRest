package com.cg.groceryapp.controller;

import java.util.*;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;

import org.springframework.http.MediaType;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.groceryapp.bean.Grocery;
import com.cg.groceryapp.staticdb.GroceryDB;

@RestController
public class GroceryController {
	
	@Produces(javax.ws.rs.core.MediaType.APPLICATION_JSON)
	@RequestMapping(value="/getGrocery")
	public List<Grocery> getGroceryList(Model model){
		
		return GroceryDB.getGroList();
	}
	
	
	@RequestMapping(value = "/groDelete/{id}", headers = "Accept=application/json", method = RequestMethod.DELETE)
	public List<Grocery> deleteGrocery(@PathVariable("id") int id) {
		System.out.println(id);
		GroceryDB.del(id);
		return GroceryDB.getGroList();
	}
	
	@RequestMapping(value = "/groUpdate", consumes = MediaType.APPLICATION_JSON_VALUE,headers = "Accept=application/json", method = RequestMethod.PUT)
	public List<Grocery> updateGrocery(@RequestBody Grocery gro) {
		System.out.println(gro);
		GroceryDB.update(gro);
		return GroceryDB.getGroList();
	}
	
	@RequestMapping(value = "/groAdd", consumes = MediaType.APPLICATION_JSON_VALUE,headers = "Accept=application/json", method = RequestMethod.POST)
	public String addGrocery(@RequestBody Grocery gro) {
		try {
			System.out.println(gro);
			GroceryDB.addGrocery(gro);
			return "success";
		} catch (Exception e) {
			return "fail";
		}
	}
	
	
	
}	
